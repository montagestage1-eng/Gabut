# Mesopotamia Part 2 - Remotion

1. Taruh audio narasi asli di `public/narasi.mp3` (file yang ada sekarang hanya placeholder hening).
2. `npm install`
3. `npm run dev` (pratinjau) / `npm run render` (hasil: out/mesopotamia.mp4)

- Ganti SRT di `public/narasi.srt`, lalu `npm run captions`.
- Geser sinkron: ubah `AUDIO_OFFSET` di `src/timing.ts`.
- Tabel koordinat: `LAYOUT.md` (cek ulang: `npm run check-layout`).
