import React from 'react';
import {Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {BeatFrame, BeatProps} from '../components/BeatFrame';
import {C, FONT} from '../theme';

// Fokus: rasi bintang tersambung titik demi titik + bulan sabit naik (dasar kalender bulan).
const STARS: [number, number][] = [
  [60, 330], [140, 240], [230, 270], [310, 170], [400, 210], [450, 110], [330, 70],
];

const Sky: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const moonY = interpolate(frame, [0, 40], [180, 0], {
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });
  return (
    <svg width={520} height={420} viewBox="0 0 520 420">
      <defs>
        <mask id="crescent">
          <rect width={520} height={420} fill="#fff" />
          <circle cx={462} cy={52} r={40} fill="#000" />
        </mask>
      </defs>
      <g transform={`translate(0 ${moonY})`}>
        <circle cx={440} cy={72} r={46} fill={C.cream} mask="url(#crescent)" />
      </g>
      {STARS.slice(1).map((s, i) => {
        const a = STARS[i];
        const p = interpolate(frame, [14 + i * 11, 14 + i * 11 + 10], [0, 1], {
          extrapolateLeft: 'clamp',
          extrapolateRight: 'clamp',
        });
        return (
          <line key={i} x1={a[0]} y1={a[1]} x2={a[0] + (s[0] - a[0]) * p} y2={a[1] + (s[1] - a[1]) * p}
            stroke={C.cream} strokeWidth={6} strokeLinecap="round" />
        );
      })}
      {STARS.map((s, i) => {
        const sp = spring({frame: frame - (10 + i * 11), fps, config: {damping: 8, stiffness: 220}});
        return (
          <g key={i} transform={`translate(${s[0]} ${s[1]}) scale(${sp})`}>
            <polygon points="0,-22 6,-6 22,0 6,6 0,22 -6,6 -22,0 -6,-6" fill={C.gold}
              stroke={C.ink} strokeWidth={4} strokeLinejoin="round" />
          </g>
        );
      })}
      <text x={20} y={400} fontFamily={FONT} fontSize={30} fill={C.cream} stroke={C.ink} strokeWidth={7}
        paintOrder="stroke" opacity={frame > 90 ? 1 : 0}>1 bulan = 1 siklus bulan</text>
    </svg>
  );
};

export const Beat5: React.FC<BeatProps> = ({duration}) => (
  <BeatFrame
    beat={5}
    duration={duration}
    bg="bg5.jpg"
    cam={{s0: 1.3, s1: 1.3, x0: 0, x1: 0, y0: -280, y1: 280}}
    title="Langit & Kalender"
    label="Kalender bulan"
    pose="jelaskan"
    wipeIn="slideU"
    wipeOut="dawn"
  >
    <Sky />
  </BeatFrame>
);
