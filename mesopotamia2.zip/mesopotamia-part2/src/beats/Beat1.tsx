import React from 'react';
import {Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {BeatFrame, BeatProps} from '../components/BeatFrame';
import {C, FONT} from '../theme';

// Fokus: dua sungai (Tigris & Eufrat) digambar -> "di antara dua sungai" = Mesopotamia.
const Rivers: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const draw = (from: number, to: number) =>
    interpolate(frame, [from, to], [0, 1], {
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp',
      easing: Easing.inOut(Easing.cubic),
    });
  const p1 = draw(10, 60);
  const p2 = draw(24, 74);
  const tag = spring({frame: frame - 70, fps, config: {damping: 10, stiffness: 180}});
  const tigris = 'M70 30 C 150 190, 60 380, 200 520 S 300 650 330 690';
  const eufrat = 'M450 30 C 380 210, 470 400, 360 540 S 340 650 335 690';
  return (
    <svg width={520} height={700} viewBox="0 0 520 700">
      {[tigris, eufrat].map((d, i) => (
        <g key={i}>
          <path d={d} fill="none" stroke={C.cream} strokeWidth={34} strokeLinecap="round"
            pathLength={1} strokeDasharray={1} strokeDashoffset={1 - (i === 0 ? p1 : p2)} />
          <path d={d} fill="none" stroke={C.water} strokeWidth={22} strokeLinecap="round"
            pathLength={1} strokeDasharray={1} strokeDashoffset={1 - (i === 0 ? p1 : p2)} />
        </g>
      ))}
      <text x={96} y={64} fontFamily={FONT} fontSize={34} fill={C.cream} stroke={C.ink}
        strokeWidth={7} paintOrder="stroke" opacity={p1 > 0.95 ? 1 : 0}>Tigris</text>
      <text x={344} y={64} fontFamily={FONT} fontSize={34} fill={C.cream} stroke={C.ink}
        strokeWidth={7} paintOrder="stroke" opacity={p2 > 0.95 ? 1 : 0}>Eufrat</text>
      <g transform={`translate(270 350) scale(${tag})`}>
        <polygon points="-130,-34 -60,-42 70,-38 130,-32 134,6 126,36 20,40 -80,36 -134,30 -128,-4"
          fill={C.gold} stroke={C.ink} strokeWidth={6} strokeLinejoin="round" />
        <text x={0} y={11} textAnchor="middle" fontFamily={FONT} fontSize={30} fill={C.ink}>ANTARA 2 SUNGAI</text>
      </g>
    </svg>
  );
};

export const Beat1: React.FC<BeatProps> = ({duration}) => (
  <BeatFrame
    beat={1}
    duration={duration}
    bg="bg1.jpg"
    cam={{s0: 1.3, s1: 1.04, x0: -170, x1: 0, y0: 290, y1: 0}}
    title="Penemu yang Mengubah Dunia"
    label="Sumeria · ±3500 SM"
    pose="jelaskan"
    wipeOut="cap"
  >
    <Rivers />
  </BeatFrame>
);
