import React from 'react';
import {Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {BeatFrame, BeatProps} from '../components/BeatFrame';
import {C, FONT} from '../theme';

// Fokus: angka 60 distempel, lingkaran dibagi 6 irisan x 10 = 60.
const CX = 260;
const CY = 410;
const R = 170;

const Sixty: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const stamp = spring({frame: frame - 6, fps, config: {damping: 9, stiffness: 200}});
  const ring = interpolate(frame, [24, 70], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.inOut(Easing.cubic),
  });
  return (
    <svg width={520} height={640} viewBox="0 0 520 640">
      <g transform={`translate(260 130) scale(${2 - stamp})`}>
        <text x={0} y={80} textAnchor="middle" fontFamily={FONT} fontSize={230} fill={C.gold}
          stroke={C.ink} strokeWidth={16} paintOrder="stroke">60</text>
      </g>
      <circle cx={CX} cy={CY} r={R} fill="rgba(246,232,200,0.82)" stroke={C.ink} strokeWidth={10}
        pathLength={1} strokeDasharray={1} strokeDashoffset={1 - ring}
        transform={`rotate(-90 ${CX} ${CY})`} />
      {Array.from({length: 6}, (_, i) => {
        const a = (i * 60 - 90) * (Math.PI / 180);
        const grow = interpolate(frame, [34 + i * 6, 44 + i * 6], [0, 1], {
          extrapolateLeft: 'clamp',
          extrapolateRight: 'clamp',
        });
        const mid = ((i * 60 + 30 - 90) * Math.PI) / 180;
        const num = spring({frame: frame - (44 + i * 6), fps, config: {damping: 10, stiffness: 200}});
        return (
          <g key={i}>
            <line x1={CX} y1={CY} x2={CX + Math.cos(a) * R * grow} y2={CY + Math.sin(a) * R * grow}
              stroke={C.ink} strokeWidth={8} strokeLinecap="round" />
            <text x={CX + Math.cos(mid) * R * 0.6} y={CY + Math.sin(mid) * R * 0.6 + 14}
              textAnchor="middle" fontFamily={FONT} fontSize={40} fill={C.cloak}
              opacity={num > 0.02 ? 1 : 0}
              transform={`scale(${1})`}>{(i + 1) * 10}</text>
          </g>
        );
      })}
    </svg>
  );
};

export const Beat4: React.FC<BeatProps> = ({duration}) => (
  <BeatFrame
    beat={4}
    duration={duration}
    bg="bg4.jpg"
    cam={{s0: 1.2, s1: 1.0, x0: 80, x1: 0, y0: 120, y1: 0}}
    title="Bilangan Basis 60"
    label="Sumeria–Babilonia"
    pose="g3"
    wipeIn="wheel"
    wipeOut="slideU"
  >
    <Sixty />
  </BeatFrame>
);
