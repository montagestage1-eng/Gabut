import React from 'react';
import {interpolate, interpolateColors, useCurrentFrame} from 'remotion';
import {BeatFrame, BeatProps} from '../components/BeatFrame';
import {C, FONT} from '../theme';

// Fokus: ziggurat 5 tingkat; tiap tingkat menyala dari bawah ke atas, tangga di depan.
const TIERS = [
  {w: 480, y: 540},
  {w: 400, y: 450},
  {w: 320, y: 360},
  {w: 240, y: 270},
  {w: 160, y: 180},
];
const H_TIER = 90;

const Ziggurat: React.FC = () => {
  const frame = useCurrentFrame();
  const lit = (i: number) =>
    interpolate(frame, [10 + i * 16, 26 + i * 16], [0, 1], {
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp',
    });
  const shrine = lit(5);
  return (
    <svg width={520} height={660} viewBox="0 0 520 660">
      {TIERS.map((t, i) => (
        <rect key={i} x={260 - t.w / 2} y={t.y} width={t.w} height={H_TIER}
          fill={interpolateColors(lit(i), [0, 1], ['#9C6B3C', C.gold])}
          stroke={C.ink} strokeWidth={7} strokeLinejoin="round" />
      ))}
      <rect x={215} y={120} width={90} height={60}
        fill={interpolateColors(shrine, [0, 1], ['#9C6B3C', C.cream])} stroke={C.ink} strokeWidth={7} />
      {Array.from({length: 9}, (_, k) => (
        <line key={k} x1={236} y1={620 - k * 50} x2={284} y2={620 - k * 50}
          stroke={C.ink} strokeWidth={6} opacity={lit(Math.min(4, Math.floor(k / 2))) > 0.5 ? 1 : 0} />
      ))}
      <text x={260} y={100} textAnchor="middle" fontFamily={FONT} fontSize={30} fill={C.cream}
        stroke={C.ink} strokeWidth={7} paintOrder="stroke" opacity={shrine > 0.9 ? 1 : 0}>PUSAT IBADAH</text>
    </svg>
  );
};

export const Beat7: React.FC<BeatProps> = ({duration}) => (
  <BeatFrame
    beat={7}
    duration={duration}
    bg="bg7.jpg"
    cam={{s0: 1.3, s1: 1.3, x0: 0, x1: 0, y0: -280, y1: 280}}
    title="Ziggurat"
    label="Ur · ±2100 SM"
    pose="g5"
    wipeIn="slideR"
    wipeOut="zoom"
  >
    <Ziggurat />
  </BeatFrame>
);
