import React from 'react';
import {Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {BeatFrame, BeatProps} from '../components/BeatFrame';
import {C} from '../theme';

// Fokus: kanal irigasi digambar, air mengalir, tunas gandum tumbuh di tepinya.
const CANAL = 'M 400 20 C 470 170, 90 220, 150 390 S 430 540, 290 700';
const SPROUTS: [number, number][] = [[80, 300], [450, 420], [100, 560], [380, 150]];

const Canal: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const draw = interpolate(frame, [4, 44], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.inOut(Easing.cubic),
  });
  const flow = interpolate(frame % 40, [0, 40], [0, -80]);
  return (
    <svg width={520} height={720} viewBox="0 0 520 720">
      <path d={CANAL} fill="none" stroke={C.ink} strokeWidth={70} strokeLinecap="round"
        pathLength={1} strokeDasharray={1} strokeDashoffset={1 - draw} />
      <path d={CANAL} fill="none" stroke={C.clayLight} strokeWidth={58} strokeLinecap="round"
        pathLength={1} strokeDasharray={1} strokeDashoffset={1 - draw} />
      <path d={CANAL} fill="none" stroke={C.water} strokeWidth={38} strokeLinecap="round"
        pathLength={1} strokeDasharray={1} strokeDashoffset={1 - draw} />
      {draw > 0.99 ? (
        <path d={CANAL} fill="none" stroke={C.waterLight} strokeWidth={10} strokeLinecap="round"
          strokeDasharray="26 54" strokeDashoffset={flow} />
      ) : null}
      {SPROUTS.map(([x, y], i) => {
        const g = spring({frame: frame - (50 + i * 10), fps, config: {damping: 12, stiffness: 120}});
        return (
          <g key={i} transform={`translate(${x} ${y})`}>
            <g style={{transformBox: 'fill-box', transformOrigin: '50% 100%', transform: `scaleY(${g})`}}>
              {[-14, 0, 14].map((dx, k) => (
                <g key={k}>
                  <line x1={dx} y1={0} x2={dx * 1.4} y2={-70 + Math.abs(dx)} stroke={C.ink} strokeWidth={9} strokeLinecap="round" />
                  <line x1={dx} y1={0} x2={dx * 1.4} y2={-70 + Math.abs(dx)} stroke={C.gold} strokeWidth={4} strokeLinecap="round" />
                </g>
              ))}
            </g>
          </g>
        );
      })}
    </svg>
  );
};

export const Beat6: React.FC<BeatProps> = ({duration}) => (
  <BeatFrame
    beat={6}
    duration={duration}
    bg="bg6.jpg"
    cam={{s0: 1.3, s1: 1.3, x0: 140, x1: -140, y0: 200, y1: -100}}
    title="Irigasi & Pertanian"
    label="Lembah Tigris–Eufrat"
    pose="jalan"
    wipeIn="dawn"
    wipeOut="slideR"
  >
    <Canal />
  </BeatFrame>
);
