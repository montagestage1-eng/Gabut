import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {CAPTIONS} from '../captions';
import {FIXED, rectStyle} from '../layout';
import {toFrame} from '../timing';
import {C, FONT} from '../theme';

const MAX_CHARS_PER_LINE = 16;
const MAX_LINES = 2;
const LINE_H = 104;
const FONT_SIZE = 68;

type W = {i: number; w: string; from: number; to: number};
type Chunk = {lines: W[][]; from: number; to: number};

// Susun kata jadi potongan max 2 baris x 16 huruf; potong juga di akhir kalimat.
const buildChunks = (): Chunk[] => {
  const words: W[] = CAPTIONS.map((c, i) => ({
    i,
    w: c.w,
    from: toFrame(c.start),
    to: toFrame(c.end),
  }));
  const chunks: Chunk[] = [];
  let lines: W[][] = [[]];
  const lineLen = (l: W[]) => l.reduce((a, x) => a + x.w.length, 0) + Math.max(0, l.length - 1);
  const flush = () => {
    const flat = lines.flat();
    if (flat.length) chunks.push({lines, from: flat[0].from, to: flat[flat.length - 1].to});
    lines = [[]];
  };
  for (const word of words) {
    let cur = lines[lines.length - 1];
    if (cur.length && lineLen(cur) + 1 + word.w.length > MAX_CHARS_PER_LINE) {
      if (lines.length >= MAX_LINES) {
        flush();
        cur = lines[0];
      } else {
        lines.push([]);
        cur = lines[lines.length - 1];
      }
    }
    cur.push(word);
    if (/[.?!]$/.test(word.w)) flush();
  }
  flush();
  // tampil sampai potongan berikutnya mulai (maks 0,5 dtk setelah kata terakhir)
  return chunks.map((c, k) => {
    const next = chunks[k + 1];
    const hold = c.to + 15;
    return {...c, to: next ? Math.min(next.from, hold) : hold};
  });
};

const CHUNKS = buildChunks();

export const Subtitles: React.FC = () => {
  const frame = useCurrentFrame();
  const chunk = CHUNKS.find((c) => frame >= c.from && frame < c.to);
  if (!chunk) return null;
  const r = FIXED.subtitle;
  const n = chunk.lines.length;
  const top0 = (r.h - n * LINE_H) / 2;
  return (
    <div style={rectStyle(r)}>
      {chunk.lines.map((line, li) => (
        <div
          key={li}
          style={{
            position: 'absolute',
            left: 0,
            top: top0 + li * LINE_H,
            width: r.w,
            height: LINE_H,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            whiteSpace: 'nowrap',
          }}
        >
          {line.map((w) => {
            const active = frame >= w.from && frame < toNextStart(w);
            const pop = active
              ? interpolate(frame - w.from, [0, 5], [0.86, 1], {extrapolateRight: 'clamp'})
              : 1;
            return (
              <span
                key={w.i}
                style={{
                  display: 'inline-block',
                  margin: '0 3px',
                  padding: '0 10px',
                  fontFamily: FONT,
                  fontSize: FONT_SIZE,
                  lineHeight: `${LINE_H - 14}px`,
                  background: active ? C.highlight : 'transparent',
                  color: active ? C.ink : C.cream,
                  border: active ? `5px solid ${C.ink}` : '5px solid transparent',
                  transform: `scale(${pop}) rotate(${active ? -1.2 : 0}deg)`,
                  WebkitTextStroke: active ? '0px' : `9px ${C.ink}`,
                  paintOrder: 'stroke fill',
                }}
              >
                {w.w}
              </span>
            );
          })}
        </div>
      ))}
    </div>
  );
};

// kata aktif sampai kata berikutnya mulai (supaya kotak kuning tidak berkedip di celah antar kata)
const toNextStart = (w: W): number => {
  const next = CAPTIONS[w.i + 1];
  const end = next ? Math.max(w.to, toFrame(next.start)) : w.to + 6;
  return Math.min(end, w.to + 10);
};
