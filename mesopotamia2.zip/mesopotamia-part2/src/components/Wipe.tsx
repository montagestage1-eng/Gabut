import React from 'react';
import {random} from 'remotion';
import {H, W} from '../layout';
import {C} from '../theme';

export type WipeKind = 'cap' | 'slideL' | 'slideR' | 'wheel' | 'dawn' | 'slideU' | 'zoom' | 'black';

// Pelat tanah liat penuh layar dengan goresan baji (seed tetap).
const ClayPlate: React.FC<{gradient?: boolean}> = ({gradient}) => {
  const wedges = Array.from({length: 46}, (_, i) => {
    const x = random(`wx-${i}`) * W;
    const y = random(`wy-${i}`) * H;
    const a = random(`wa-${i}`) * 360;
    const len = 60 + random(`wl-${i}`) * 90;
    return {x, y, a, len};
  });
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`}>
      <defs>
        <linearGradient id="dawnG" x1="0" y1="1" x2="0" y2="0">
          <stop offset="0" stopColor="#F2A541" />
          <stop offset="0.5" stopColor="#E0763A" />
          <stop offset="1" stopColor="#C98F55" />
        </linearGradient>
      </defs>
      <rect width={W} height={H} fill={gradient ? 'url(#dawnG)' : C.clay} />
      {wedges.map((w, i) => (
        <g key={i} transform={`translate(${w.x} ${w.y}) rotate(${w.a})`}>
          <polygon points={`0,-9 0,9 ${w.len},0`} fill={C.clayDark} opacity={0.55} />
        </g>
      ))}
      <rect x={0} y={0} width={W} height={H} fill="none" stroke={C.ink} strokeWidth={14} />
    </svg>
  );
};

// cover: 0 = tidak menutup, 1 = menutup penuh. phase: 'out' menutup, 'in' membuka.
export const Wipe: React.FC<{kind: WipeKind; phase: 'in' | 'out'; cover: number}> = ({
  kind,
  phase,
  cover,
}) => {
  if (cover <= 0) return null;
  const dir = phase === 'out' ? 1 : -1;
  const base: React.CSSProperties = {position: 'absolute', left: 0, top: 0, width: W, height: H};

  if (kind === 'black') {
    return <div style={{...base, background: '#000', opacity: cover}} />;
  }
  if (kind === 'slideL' || kind === 'cap') {
    const x = dir * W * (1 - cover);
    return (
      <div style={{...base, transform: `translateX(${x}px)`}}>
        <ClayPlate />
      </div>
    );
  }
  if (kind === 'slideR') {
    const x = -dir * W * (1 - cover);
    return (
      <div style={{...base, transform: `translateX(${x}px)`}}>
        <ClayPlate />
      </div>
    );
  }
  if (kind === 'dawn' || kind === 'slideU') {
    const y = dir * H * (1 - cover);
    return (
      <div style={{...base, transform: `translateY(${y}px)`}}>
        <ClayPlate gradient={kind === 'dawn'} />
      </div>
    );
  }
  // wheel / zoom: lingkaran tanah liat yang membesar dari titik tetap
  const cy = kind === 'zoom' ? 640 : H / 2;
  const r = 1750 * cover;
  return (
    <div style={{...base, clipPath: `circle(${r}px at ${W / 2}px ${cy}px)`}}>
      <ClayPlate />
    </div>
  );
};
