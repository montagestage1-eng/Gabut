import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {FIXED, MOTION, rectStyle} from '../layout';
import {C, FONT} from '../theme';

// Judul adegan: papan tanah liat yang "distempel" ke layar (muncul tegas, bukan fade).
export const Title: React.FC<{text: string}> = ({text}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const r = FIXED.title;
  const start = 4;
  const sp = spring({frame: frame - start, fps, config: {damping: 11, stiffness: 220}});
  const scale = MOTION.titleStampScale - (MOTION.titleStampScale - 1) * sp;
  const rot = interpolate(sp, [0, 1], [-3, -1]);
  const fs = Math.min(72, Math.floor(820 / (text.length * 0.64)));
  if (frame < start) return null;
  return (
    <div style={{...rectStyle(r), transform: `rotate(${rot}deg) scale(${scale})`}}>
      <svg width={r.w} height={r.h} viewBox="0 0 900 140" style={{position: 'absolute', left: 0, top: 0}}>
        <polygon
          points="10,18 120,6 300,13 520,4 740,10 890,15 896,70 888,127 700,134 480,127 250,136 90,130 6,123 12,70"
          fill={C.clayLight}
          stroke={C.ink}
          strokeWidth={6}
          strokeLinejoin="round"
        />
        <polygon
          points="30,30 120,22 300,28 520,20 740,26 872,30 878,70 870,112 700,118 480,112 250,120 90,114 26,108 32,70"
          fill="none"
          stroke={C.clayDark}
          strokeWidth={3}
          strokeDasharray="14 8"
        />
      </svg>
      <div
        style={{
          position: 'absolute',
          left: 0,
          top: 0,
          width: r.w,
          height: r.h,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontFamily: FONT,
          fontSize: fs,
          color: C.ink,
          whiteSpace: 'nowrap',
          letterSpacing: 1,
        }}
      >
        {text}
      </div>
    </div>
  );
};
