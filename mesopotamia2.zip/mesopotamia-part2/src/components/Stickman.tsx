import React from 'react';
import {Easing, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {FIXED, MOTION, rectStyle} from '../layout';
import {POSES, PoseName} from '../poses';
import {C} from '../theme';

// Stickman narator: PNG pose dari lembar desain karakter, ditaruh di kotak eksplisit FIXED.stickman.
export const Stickman: React.FC<{pose: PoseName}> = ({pose}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const r = FIXED.stickman;
  const [pw, ph] = POSES[pose];
  const k = Math.min(r.w / pw, r.h / ph);
  const dw = Math.round(pw * k);
  const dh = Math.round(ph * k);
  const sp = spring({frame: frame - 6, fps, config: {damping: 15, stiffness: 120}});
  const slide = MOTION.stickmanSlideFromX * (1 - sp);
  // napas pelan: siklus 60 frame, hanya dari interpolate
  const bob = interpolate(frame % 60, [0, 30, 60], [0, -MOTION.stickmanBobPx, 0], {
    easing: Easing.inOut(Easing.sin),
  });
  const o = 4;
  const outline = [
    `drop-shadow(${o}px 0 0 ${C.cream})`,
    `drop-shadow(-${o}px 0 0 ${C.cream})`,
    `drop-shadow(0 ${o}px 0 ${C.cream})`,
    `drop-shadow(0 -${o}px 0 ${C.cream})`,
  ].join(' ');
  return (
    <div style={{...rectStyle(r), transform: `translateX(${slide}px)`}}>
      <div
        style={{
          position: 'absolute',
          left: (r.w - dw * 0.9) / 2,
          top: r.h - 14,
          width: dw * 0.9,
          height: 26,
          borderRadius: '50%',
          background: 'rgba(30,16,6,0.45)',
        }}
      />
      <Img
        src={staticFile(`char/${pose}.png`)}
        style={{
          position: 'absolute',
          left: (r.w - dw) / 2,
          top: r.h - dh + bob,
          width: dw,
          height: dh,
          filter: outline,
        }}
      />
    </div>
  );
};
