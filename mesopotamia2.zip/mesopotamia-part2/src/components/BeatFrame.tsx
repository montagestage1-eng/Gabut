import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';
import {FOCUS, rectStyle} from '../layout';
import {PoseName} from '../poses';
import {Background, Cam} from './Background';
import {Label} from './Label';
import {Stickman} from './Stickman';
import {Title} from './Title';
import {Wipe, WipeKind} from './Wipe';

export const WIPE_FRAMES = 12;
export const FINAL_FADE_FRAMES = 30;

export type BeatProps = {duration: number};

type Props = BeatProps & {
  beat: number; // 1..8, menentukan kotak area fokus
  bg: string;
  cam: Cam;
  title: string;
  label: string;
  pose: PoseName;
  wipeIn?: WipeKind; // pembuka (menutup penuh di frame 0, lalu membuka)
  wipeOut: WipeKind; // penutup
  children: React.ReactNode; // elemen fokus (diletakkan di dalam kotak FOCUS[beat])
};

export const BeatFrame: React.FC<Props> = ({
  beat,
  duration,
  bg,
  cam,
  title,
  label,
  pose,
  wipeIn,
  wipeOut,
  children,
}) => {
  const frame = useCurrentFrame();
  const ease = Easing.inOut(Easing.cubic);
  const inCover = wipeIn
    ? 1 - interpolate(frame, [0, WIPE_FRAMES], [0, 1], {extrapolateRight: 'clamp', easing: ease})
    : 0;
  const outLen = wipeOut === 'black' ? FINAL_FADE_FRAMES : WIPE_FRAMES;
  const outCover = interpolate(frame, [duration - 1 - outLen, duration - 1], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: wipeOut === 'black' ? Easing.linear : ease,
  });
  return (
    <AbsoluteFill style={{background: '#000', overflow: 'hidden'}}>
      <Background file={bg} cam={cam} duration={duration} />
      <AbsoluteFill
        style={{
          background:
            'linear-gradient(180deg, rgba(30,16,6,0.55) 0px, rgba(30,16,6,0) 330px, rgba(30,16,6,0) 1380px, rgba(30,16,6,0.72) 1920px)',
        }}
      />
      <div style={{...rectStyle(FOCUS[String(beat)]), overflow: 'hidden'}}>{children}</div>
      <Stickman pose={pose} />
      <Label text={label} />
      <Title text={title} />
      {wipeIn ? <Wipe kind={wipeIn} phase="in" cover={inCover} /> : null}
      <Wipe kind={wipeOut} phase="out" cover={outCover} />
    </AbsoluteFill>
  );
};
