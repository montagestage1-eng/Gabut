import React from 'react';
import {Easing, Img, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {H, W} from '../layout';

export type Cam = {s0: number; s1: number; x0: number; x1: number; y0: number; y1: number};

const clamp = (v: number, lim: number) => Math.max(-lim, Math.min(lim, v));

// Kamera dolly: zoom + geser. Geseran dibatasi supaya tepi foto tidak pernah kelihatan.
export const Background: React.FC<{file: string; cam: Cam; duration: number}> = ({
  file,
  cam,
  duration,
}) => {
  const frame = useCurrentFrame();
  const p = interpolate(frame, [0, Math.max(1, duration - 1)], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.inOut(Easing.quad),
  });
  const s = cam.s0 + (cam.s1 - cam.s0) * p;
  const tx = clamp(cam.x0 + (cam.x1 - cam.x0) * p, ((s - 1) * W) / 2);
  const ty = clamp(cam.y0 + (cam.y1 - cam.y0) * p, ((s - 1) * H) / 2);
  return (
    <Img
      src={staticFile(`img/${file}`)}
      style={{
        position: 'absolute',
        left: 0,
        top: 0,
        width: W,
        height: H,
        objectFit: 'cover',
        transformOrigin: '50% 50%',
        transform: `translate(${tx}px, ${ty}px) scale(${s})`,
      }}
    />
  );
};
