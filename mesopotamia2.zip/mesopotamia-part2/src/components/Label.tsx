import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {FIXED, MOTION, rectStyle} from '../layout';
import {C, FONT} from '../theme';

// Label info (nama tempat / tahun): tablet kecil meluncur masuk dari kiri.
export const Label: React.FC<{text: string}> = ({text}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const r = FIXED.label;
  const sp = spring({frame: frame - 14, fps, config: {damping: 16, stiffness: 140}});
  const x = MOTION.labelSlideFromX * (1 - sp);
  const fs = Math.min(46, Math.floor(380 / (text.length * 0.64)));
  return (
    <div style={{...rectStyle(r), transform: `translateX(${x}px) rotate(1deg)`}}>
      <svg width={r.w} height={r.h} viewBox="0 0 460 110" style={{position: 'absolute', left: 0, top: 0}}>
        <polygon
          points="8,14 150,6 320,12 452,8 456,56 450,100 300,104 140,98 6,102 10,56"
          fill={C.gold}
          stroke={C.ink}
          strokeWidth={6}
          strokeLinejoin="round"
        />
      </svg>
      <div
        style={{
          position: 'absolute',
          left: 0,
          top: 0,
          width: r.w,
          height: r.h,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontFamily: FONT,
          fontSize: fs,
          color: C.ink,
          whiteSpace: 'nowrap',
        }}
      >
        {text}
      </div>
    </div>
  );
};
