import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {Beat1} from './beats/Beat1';
import {Beat2} from './beats/Beat2';
import {Beat3} from './beats/Beat3';
import {Beat4} from './beats/Beat4';
import {Beat5} from './beats/Beat5';
import {Beat6} from './beats/Beat6';
import {Beat7} from './beats/Beat7';
import {Beat8} from './beats/Beat8';
import {Subtitles} from './components/Subtitles';
import {BEAT_FRAMES} from './timing';

const BEATS = [Beat1, Beat2, Beat3, Beat4, Beat5, Beat6, Beat7, Beat8];

export const Main: React.FC = () => {
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <Audio src={staticFile('narasi.mp3')} />
      {BEATS.map((Beat, i) => (
        <Sequence
          key={i}
          from={BEAT_FRAMES[i].from}
          durationInFrames={BEAT_FRAMES[i].duration}
          name={`Beat ${i + 1}`}
        >
          <Beat duration={BEAT_FRAMES[i].duration} />
        </Sequence>
      ))}
      <Subtitles />
    </AbsoluteFill>
  );
};
