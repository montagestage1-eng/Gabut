// Ukuran asli PNG pose (piksel) di public/char/
export const POSES = {
  belakang: [276, 663],
  duduk: [249, 309],
  g1: [228, 396],
  g3: [267, 384],
  g5: [315, 357],
  g7: [327, 363],
  g9: [261, 336],
  jalan: [255, 387],
  jelaskan: [312, 432],
  tunjuk: [330, 459],
  utama: [528, 711],
} as const;

export type PoseName = keyof typeof POSES;
