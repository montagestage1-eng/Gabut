export const C = {
  clay: '#C98F55',
  clayLight: '#E3B982',
  clayDark: '#7A4A22',
  ink: '#2B1A0E',
  cream: '#F6E8C8',
  cloak: '#7A1F14',
  gold: '#E8B23A',
  highlight: '#FFD43B',
  water: '#2F86A6',
  waterLight: '#9ADBEA',
  night: '#12183A',
};
export const FONT = "'Arial Black', 'Segoe UI Black', Impact, 'Helvetica Neue', sans-serif";
