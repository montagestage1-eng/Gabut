import {CAPTIONS} from './captions';

// Tiap beat dimulai pada kata pertama dari frasa jangkar ini (dicari berurutan di captions).
export const BEAT_ANCHOR_PHRASES: string[][] = [
  ['Seiring'], // 1 Mesopotamia yang maju
  ['Bangsa'], // 2 Cuneiform
  ['Mereka', 'juga'], // 3 Roda
  ['Dalam'], // 4 Basis 60
  ['Mereka', 'mempelajari'], // 5 Astronomi
  ['serta'], // 6 Irigasi
  ['Tak'], // 7 Ziggurat
  ['Penemuan'], // 8 Warisan
];

const norm = (s: string) => s.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');

export const BEAT_ANCHORS: number[] = (() => {
  const out: number[] = [];
  let from = 0;
  for (const phrase of BEAT_ANCHOR_PHRASES) {
    let found = -1;
    for (let i = from; i < CAPTIONS.length; i++) {
      if (phrase.every((p, k) => CAPTIONS[i + k] && norm(CAPTIONS[i + k].w) === norm(p))) {
        found = i;
        break;
      }
    }
    if (found < 0) {
      throw new Error(`Frasa jangkar tidak ditemukan di captions: ${phrase.join(' ')}`);
    }
    out.push(found);
    from = found + 1;
  }
  return out;
})();
