import {CAPTIONS} from './captions';
import {BEAT_ANCHORS} from './beats';

export const FPS = 30;

// Geser sinkron (detik). Positif = visual & subtitle lebih LAMBAT dari audio, negatif = lebih CEPAT.
export const AUDIO_OFFSET = 0;

export const toFrame = (sec: number) => Math.max(0, Math.round((sec + AUDIO_OFFSET) * FPS));

export const LAST_WORD_END = CAPTIONS[CAPTIONS.length - 1].end;
// kata terakhir + 1 detik
export const TOTAL_FRAMES = toFrame(LAST_WORD_END) + FPS;

export const BEAT_FRAMES = BEAT_ANCHORS.map((a, i) => {
  const from = i === 0 ? 0 : toFrame(CAPTIONS[a].start);
  const next =
    i + 1 < BEAT_ANCHORS.length ? toFrame(CAPTIONS[BEAT_ANCHORS[i + 1]].start) : TOTAL_FRAMES;
  return {from, duration: next - from};
});
